﻿namespace DBproject
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Studentbtn = new System.Windows.Forms.Button();
            this.Clobtn = new System.Windows.Forms.Button();
            this.Rubricbtn = new System.Windows.Forms.Button();
            this.assesmentbtn = new System.Windows.Forms.Button();
            this.RLbtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1004, 126);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(368, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(493, 46);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lab Management System";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(141, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(178, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Studentbtn
            // 
            this.Studentbtn.BackColor = System.Drawing.Color.Silver;
            this.Studentbtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Studentbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Studentbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Studentbtn.Location = new System.Drawing.Point(352, 195);
            this.Studentbtn.Name = "Studentbtn";
            this.Studentbtn.Size = new System.Drawing.Size(359, 39);
            this.Studentbtn.TabIndex = 1;
            this.Studentbtn.Text = "Manage Student";
            this.Studentbtn.UseVisualStyleBackColor = false;
            this.Studentbtn.Click += new System.EventHandler(this.Studentbtn_Click);
            // 
            // Clobtn
            // 
            this.Clobtn.BackColor = System.Drawing.Color.Silver;
            this.Clobtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Clobtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clobtn.Location = new System.Drawing.Point(352, 269);
            this.Clobtn.Name = "Clobtn";
            this.Clobtn.Size = new System.Drawing.Size(359, 39);
            this.Clobtn.TabIndex = 2;
            this.Clobtn.Text = "Manage CLO";
            this.Clobtn.UseVisualStyleBackColor = false;
            this.Clobtn.Click += new System.EventHandler(this.Clobtn_Click);
            // 
            // Rubricbtn
            // 
            this.Rubricbtn.BackColor = System.Drawing.Color.Silver;
            this.Rubricbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Rubricbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rubricbtn.Location = new System.Drawing.Point(352, 344);
            this.Rubricbtn.Name = "Rubricbtn";
            this.Rubricbtn.Size = new System.Drawing.Size(359, 39);
            this.Rubricbtn.TabIndex = 3;
            this.Rubricbtn.Text = "Manage Rubrics";
            this.Rubricbtn.UseVisualStyleBackColor = false;
            this.Rubricbtn.Click += new System.EventHandler(this.Rubricbtn_Click);
            // 
            // assesmentbtn
            // 
            this.assesmentbtn.BackColor = System.Drawing.Color.Silver;
            this.assesmentbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.assesmentbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assesmentbtn.Location = new System.Drawing.Point(352, 418);
            this.assesmentbtn.Name = "assesmentbtn";
            this.assesmentbtn.Size = new System.Drawing.Size(359, 39);
            this.assesmentbtn.TabIndex = 4;
            this.assesmentbtn.Text = "Manage Assesment";
            this.assesmentbtn.UseVisualStyleBackColor = false;
            this.assesmentbtn.Click += new System.EventHandler(this.assesmentbtn_Click);
            // 
            // RLbtn
            // 
            this.RLbtn.BackColor = System.Drawing.Color.Silver;
            this.RLbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RLbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RLbtn.Location = new System.Drawing.Point(352, 491);
            this.RLbtn.Name = "RLbtn";
            this.RLbtn.Size = new System.Drawing.Size(359, 39);
            this.RLbtn.TabIndex = 5;
            this.RLbtn.Text = "Manage Rubric Level";
            this.RLbtn.UseVisualStyleBackColor = false;
            this.RLbtn.Click += new System.EventHandler(this.RLbtn_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1028, 582);
            this.Controls.Add(this.RLbtn);
            this.Controls.Add(this.assesmentbtn);
            this.Controls.Add(this.Rubricbtn);
            this.Controls.Add(this.Clobtn);
            this.Controls.Add(this.Studentbtn);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Studentbtn;
        private System.Windows.Forms.Button Clobtn;
        private System.Windows.Forms.Button Rubricbtn;
        private System.Windows.Forms.Button assesmentbtn;
        private System.Windows.Forms.Button RLbtn;
    }
}

