import pygame
import time
import subprocess
 
pygame.init()
 
screen_width, screen_height = 800, 800
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Transition')
 
def fade_out():
    fade_surface = pygame.Surface((screen_width, screen_height))
    fade_surface.fill((0, 0, 0))
    for alpha in range(0, 300):
        fade_surface.set_alpha(alpha)
        screen.blit(fade_surface, (0, 0))
        pygame.display.update()
        pygame.time.delay(5)
fade_out()
time.sleep(2)   
subprocess.call(["/Library/Frameworks/Python.framework/Versions/3.12/bin/python3", "myfile.py"])
