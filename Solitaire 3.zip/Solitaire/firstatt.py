import random
import pygame
from pygame.locals import *
import time

pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1200, 900
CARD_WIDTH, CARD_HEIGHT = 120, 160
BACKGROUND_COLOR = (0, 128, 0)

# Load card images
card_images = {}
ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
suits = 'hcds'
for suit in suits:
    for rank in ranks:
        card_image = pygame.image.load(f'cards/{rank.lower()}{suit}.jpg')
        card_image = pygame.transform.scale(card_image, (CARD_WIDTH, CARD_HEIGHT))
        card_images[f'{rank}{suit}'] = card_image
card_images['Back'] = pygame.transform.scale(pygame.image.load('cards/back.jpg'), (CARD_WIDTH, CARD_HEIGHT))

# Define Card class
class Card:
    def __init__(self, rank, suit):
        self.rank = rank
        self.suit = suit
        self.face_up = False  # Cards start face down
        self.highlighted = False  # Add highlighted attribute

    def __str__(self):
        return f'{self.rank}{self.suit}' if self.face_up else 'Back'

    def draw(self, screen, x, y):
        card_image = card_images[str(self)]
        screen.blit(card_image, (x, y))
        if self.highlighted:
            pygame.draw.rect(screen, (255, 0, 0), (x, y, CARD_WIDTH, CARD_HEIGHT), 3)  # Draw red outline if highlighted

# Define Deck class
class Deck:
    def __init__(self):
        self.cards = [Card(rank, suit) for suit in suits for rank in ranks]
        random.shuffle(self.cards)

    def draw(self):
        return self.cards.pop() if self.cards else None

# Define node class for linked list stack
class Node:
    def __init__(self, data):
        self.data = data
        self.link = None

# Define Stack class using linked list
class Stack:
    def __init__(self):
        self.head = None

    def push(self, data):
        new_node = Node(data)
        new_node.link = self.head
        self.head = new_node

    def pop(self):
        if self.head is None:
            return None
        temp = self.head
        self.head = self.head.link
        return temp.data

    def peek(self):
        if self.head is None:
            return None
        return self.head.data

    def is_empty(self):
        return self.head is None

    def display(self):
        temp = self.head
        while temp:
            print(temp.data, end=" -> ")
            temp = temp.link
        print("None")

# Display function for piles
def display_piles(screen, piles, start_x, start_y):
    for i, pile in enumerate(piles):
        x = start_x + i * (CARD_WIDTH + 10)
        y = start_y
        temp = pile.head
        cards = []
        while temp:
            cards.append(temp.data)
            temp = temp.link
        for card in reversed(cards):  # Draw the cards in reverse order
            card.draw(screen, x, y)
            y += 30  # Vertical spacing between cards

# Define Tableau class
class Tableau:
    def __init__(self, deck):
        self.piles = [Stack() for _ in range(7)]
        for i in range(7):
            for j in range(i + 1):
                card = deck.draw()
                self.piles[i].push(card)
            # Ensure only the last card added to the stack is face-up
            last_card = self.piles[i].peek()
            if last_card:
                last_card.face_up = True

        # Debug output to check face-up status
        print("Initial Tableau Piles:")
        for i, pile in enumerate(self.piles):
            temp = pile.head
            while temp:
                print(f'Pile {i}, Card {temp.data}: {"Face up" if temp.data.face_up else "Face down"}')
                temp = temp.link

    def move(self, from_pile, to_pile):
        card = self.piles[from_pile].pop()
        if card:
            self.piles[to_pile].push(card)

    def display(self, screen):
        display_piles(screen, self.piles, 100, 150)

# Define Foundation class
class Foundation:
    def __init__(self):
        self.piles = [Stack() for _ in range(4)]

    def move(self, card, to_pile):
        self.piles[to_pile].push(card)

    def display(self, screen):
        display_piles(screen, self.piles, 100, 50)

# Main game function
def main():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('Solitaire')
    running = True
    deck = Deck()
    tableau = Tableau(deck)
    foundation = Foundation()
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False

        screen.fill(BACKGROUND_COLOR)
        tableau.display(screen)
        foundation.display(screen)
        pygame.display.update()

    pygame.quit()

if __name__ == '__main__':
    main()
