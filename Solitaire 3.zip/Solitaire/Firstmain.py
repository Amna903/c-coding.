import random
import pygame
from pygame.locals import *

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1200, 900
CARD_WIDTH, CARD_HEIGHT = 120, 160
BACKGROUND_COLOR = (0, 128, 0)

# Load card images
card_images = {}
ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
suits = 'hcds'
for suit in suits:
    for rank in ranks:
        card_image = pygame.image.load(f'cards/{rank.lower()}{suit}.jpg')
        card_image = pygame.transform.scale(card_image, (CARD_WIDTH, CARD_HEIGHT))
        card_images[f'{rank}{suit}'] = card_image
card_images['Back'] = pygame.transform.scale(pygame.image.load('cards/back.jpg'), (CARD_WIDTH, CARD_HEIGHT))
card_images['Joker'] = pygame.transform.scale(pygame.image.load('cards/joker.jpg'), (CARD_WIDTH, CARD_HEIGHT))
card_images['Joker1'] = pygame.transform.scale(pygame.image.load('cards/joker1.jpg'), (CARD_WIDTH, CARD_HEIGHT))

class Card:
    def __init__(self, rank, suit):
        self.rank = rank
        self.suit = suit
        self.face_up = False  # Cards start face down

    def __str__(self):
        return f'{self.rank}{self.suit}' if self.face_up else 'Back'

    def draw(self, screen, x, y):
        card_image = card_images[str(self)]
        screen.blit(card_image, (x, y))

class Deck:
    def __init__(self):
        self.cards = [Card(rank, suit) for suit in suits for rank in ranks]
        # Add Joker and Joker1 to the deck
        self.cards.append(Card('Joker', ''))
        self.cards.append(Card('Joker1', ''))
        random.shuffle(self.cards)

    def draw(self):
        return self.cards.pop() if self.cards else None
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Pile:
    def __init__(self):
        self.head = None
        self.tail = None

    def add_card(self, card):
        new_node = Node(card)
        if self.tail:
            self.tail.next = new_node
        self.tail = new_node
        if not self.head:
            self.head = new_node

    def remove_card(self):
        if not self.head:
            return None
        card = self.tail.data
        if self.head == self.tail:
            self.head = None
            self.tail = None
        else:
            current = self.head
            while current.next != self.tail:
                current = current.next
            current.next = None
            self.tail = current
        return card

    def top_card(self):
        return self.tail.data if self.tail else None

    def draw(self, screen, x, y):
        offset = 20
        current = self.head
        i = 0
        while current:
            if current.data.face_up:
                current.data.draw(screen, x, y + i * offset)
            else:
                screen.blit(card_images['Back'], (x, y + i * offset))
            current = current.next
            i += 1

    def cards_count(self):
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count

class Solitaire:
    def __init__(self):
        self.deck = Deck()
        self.tableau = [Pile() for _ in range(7)]
        self.foundation = [Pile() for _ in range(4)]
        self.initial_stack = Pile()  # Initial stack of 26 cards

    def setup_game(self):
        # Setup the initial stack of 26 cards
        for _ in range(26):
            card = self.deck.draw()
            if card:
                card.face_up = True
                self.initial_stack.add_card(card)

        # Setup tableau with appropriate number of cards
        for i in range(7):
            for j in range(i + 1):
                card = self.deck.draw()
                if card:
                    if j == i:  # Only the last card in each pile is face up
                        card.face_up = True
                    self.tableau[i].add_card(card)

    def draw(self, screen):
        # Draw the initial stack at the starting point of the tableau
        if self.initial_stack.head:
            self.initial_stack.top_card().draw(screen, 100, 50)

        # Draw the tableau
        for i, pile in enumerate(self.tableau):
            pile.draw(screen, 100 + i * (CARD_WIDTH + 20), 250)
 
        # Draw the foundation placeholders
        for i in range(4):
            pygame.draw.rect(screen, (255, 255, 255), (520 + i * (CARD_WIDTH + 20), 50, CARD_WIDTH, CARD_HEIGHT), 2)

        # Draw cards on the foundation
        for i, pile in enumerate(self.foundation):
            if pile.head:
                pile.top_card().draw(screen, 520 + i * (CARD_WIDTH + 20), 50)


def main():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('Solitaire')

    game = Solitaire()
    game.setup_game()
    running = True
    dragging = False
    dragged_card = None
    dragged_card_pos = (0, 0)
    original_pile = None

    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            elif event.type == MOUSEBUTTONDOWN:
                # Check for card in the initial stack
                if game.initial_stack.head:
                    card = game.initial_stack.top_card()
                    if card and card.face_up:
                        card_rect = card_images[str(card)].get_rect(topleft=(100, 50))
                        if card_rect.collidepoint(event.pos):
                            dragging = True
                            dragged_card = card
                            dragged_card_pos = event.pos
                            game.initial_stack.remove_card()
                            original_pile = game.initial_stack
                            break
                # Check for card in tableau
                for pile in game.tableau:
                    if pile.head:
                        card = pile.top_card()
                        if card and card.face_up:
                            card_rect = card_images[str(card)].get_rect(topleft=(100 + game.tableau.index(pile) * (CARD_WIDTH + 20), 250 + pile.cards_count() * 20))
                            if card_rect.collidepoint(event.pos):
                                dragging = True
                                dragged_card = card
                                dragged_card_pos = event.pos
                                pile.remove_card()
                                original_pile = pile
                                break
                # Check for card in foundation placeholders
                for i, pile in enumerate(game.foundation):
                    if pile.head:
                        card = pile.top_card()
                        if card and card.face_up:
                            card_rect = card_images[str(card)].get_rect(topleft=(520 + i * (CARD_WIDTH + 20), 50))
                            if card_rect.collidepoint(event.pos):
                                dragging = True
                                dragged_card = card
                                dragged_card_pos = event.pos
                                pile.remove_card()
                                original_pile = pile
                                break
            elif event.type == MOUSEBUTTONUP:
                if dragging:
                    placed = False
                    # Return card to initial stack if dropped back
                    if 100 <= event.pos[0] <= 220 and 50 <= event.pos[1] <= 210:
                        game.initial_stack.add_card(dragged_card)
                        placed = True
                    else:
                        for pile in game.tableau:
                            pile_rect = pygame.Rect(100 + game.tableau.index(pile) * (CARD_WIDTH + 20), 250, CARD_WIDTH, SCREEN_HEIGHT - 250)
                            if pile_rect.collidepoint(event.pos):
                                pile.add_card(dragged_card)
                                placed = True
                                break
                        if not placed:
                            for i, pile in enumerate(game.foundation):
                                pile_rect = pygame.Rect(520 + i * (CARD_WIDTH + 20), 50, CARD_WIDTH, CARD_HEIGHT)
                                if pile_rect.collidepoint(event.pos):
                                    pile.add_card(dragged_card)
                                    placed = True
                                    break
                    # If not placed, return card to original pile
                    if not placed and original_pile:
                        original_pile.add_card(dragged_card)
                    # Now uncover the next card if it exists in the original pile
                    if original_pile and original_pile.head and not original_pile.top_card().face_up:
                        original_pile.top_card().face_up = True

                    dragging = False
                    dragged_card = None
                    dragged_card_pos = (0, 0)
            elif event.type  == MOUSEMOTION:
                if dragging:
                    dragged_card_pos = event.pos

        screen.fill(BACKGROUND_COLOR)
        game.draw(screen)

        if dragging and dragged_card:
            screen.blit(card_images[str(dragged_card)], dragged_card_pos)

        pygame.display.flip()

    pygame.quit()

if __name__ == '__main__':
    main()