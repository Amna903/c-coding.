from turtle import *
import time
import subprocess
import os

screen = Screen()
screen.setup(width=800, height=800)
screen.bgcolor('black')
screen.bgpic("bgim.gif")
screen.cv._rootwindow.resizable(False, False)

speed(0)
pensize(2)
hideturtle()
tracer(0, 0)

penup()
goto(0, 0)
pendown()

for i in range(175):
    if i == 140:
        update()
        tracer(1, 0)
    color('#909090')
    circle(5 - i, 100)
    lt(80)
    circle(5 - i, 100)
    rt(160)

penup()
color('#f0f0f0')
style = ('Verdana', 80, 'bold')
text = "SOLITAIRE"

start_x = -235
y = -40

shadow_offset_x = 3
shadow_offset_y = -3

for i, letter in enumerate(text):
    goto(start_x + i * 60 + shadow_offset_x, y + shadow_offset_y)
    color('dark green')
    write(letter, font=style, align="center")

    goto(start_x + i * 60, y)
    color('#909090')
    write(letter, font=style, align="center")

    time.sleep(0.1)

done()

# Wait for 2 seconds before launching the next script
time.sleep(2)
 
subprocess.call(["/Library/Frameworks/Python.framework/Versions/3.12/bin/python3", "t.py"])

