﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
    using System.IO;
    using Newtonsoft.Json;
namespace Library.Fh
{
    using System;
     
        public class UserManagement
        { 
            private string filePath = "C:\\twitter1\\Twitter\\user.json";

        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                var jArray = Newtonsoft.Json.Linq.JArray.Parse(json);

                foreach (var item in jArray)
                {
                    users.Add(new User((Newtonsoft.Json.Linq.JObject)item));
                }
            }

           

            return users;
        }


        public void UpdateUserData(User user, string originalUsername)
            {
                List<User> users = GetAllUsers();
                int index = users.FindIndex(u => u.GetUsername() == originalUsername);
                if (index != -1)
                { Console.WriteLine($"UserId: {user.UserId}, Username: {user.GetUsername()}, Role: {user.GetRole()}, Email: {user.GetEmail()}, Gender: {user.Getgender()}, ProfilePicturePath: {user.GetProfilePicturePath()}, Bluetick: {user.Bluetick}");
         
                    users[index] = user;
                    SaveUsersToFile(users); 
                          
            }
            }

            public List<User> GetUsersLike(string username)
            {
                List<User> users = GetAllUsers();
                return users.FindAll(u => u.GetUsername().Contains(username));
            }

            public string GetProfilePicturePath(int userId)
            {
                List<User> users = GetAllUsers();
                User user = users.Find(u => u.UserId == userId);
                return user?.ProfilePicturePath;
            }

            public void UpdateProfilePicturePath(string username, string profilePicturePath)
            {
                List<User> users = GetAllUsers();
                User user = users.Find(u => u.GetUsername() == username);
                if (user != null)
                {
                    user.ProfilePicturePath = profilePicturePath;
                    SaveUsersToFile(users);
                }
            }

            public bool IsUsernameUnique(string username)
            {
                List<User> users = GetAllUsers();
                return !users.Exists(u => u.GetUsername() == username);
            }

            public void UpdateBluetick(string username)
            {
                List<User> users = GetAllUsers();
                User user = users.Find(u => u.GetUsername() == username);
                if (user != null)
                {
                    user.Bluetick = true;
                    SaveUsersToFile(users);
                }
            }

            public void DeleteUser(int userId)
            {
                List<User> users = GetAllUsers();
                users.RemoveAll(u => u.UserId == userId);
                SaveUsersToFile(users);
            }

            private void SaveUsersToFile(List<User> users)
            {
                string json = JsonConvert.SerializeObject(users);
                File.WriteAllText(filePath, json);
            }
        }
    }

