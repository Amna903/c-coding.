﻿using System;
using System.Data.SqlClient;

namespace Library
{

    public class TweetsAction : IFeatures
    {
        private int tweetId;
        private int userId;
          TweetManagement u = new TweetManagement();
         public TweetsAction(Tweet tweet, User user)
        {
            this.tweetId = tweet.TweetId;
            this.userId = user.UserId;
        }


        public void Like()
        {
             string checkQuery = "SELECT LikeCount FROM UserActions WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery))
            {
                checkCmd.Parameters.AddWithValue("@userId", userId);
                checkCmd.Parameters.AddWithValue("@tweetId", tweetId);
                object result = Database.ExecuteScalar(checkCmd);

                 if (result == null)
                {
                    string query = "INSERT INTO UserActions (tweetId, userId, LikeCount) VALUES (@tweetId, @userId, 1)";
                    using (SqlCommand cmd = new SqlCommand(query))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(cmd);
                    }
                    string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Like' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                    {
                        notifyCmd.Parameters.AddWithValue("@userId", userId);
                        notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(notifyCmd);
                    }
                }
                else if (result != null)
                {

                    int likeCount;
                    if (result is DBNull)     {
                        likeCount = 1;
                    }
                    else        {
                        likeCount = (int)result;
                        likeCount = likeCount == 0 ? 1 : 0;
                    }

                    string query = "UPDATE UserActions SET LikeCount = @likeCount WHERE userId = @userId AND tweetId = @tweetId";
                    using (SqlCommand cmd = new SqlCommand(query))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        cmd.Parameters.AddWithValue("@likeCount", likeCount);
                        Database.ExecuteQuery(cmd);
                    }
                }
            }
        }

        public void Comment(string commentText)
        {
              string insertQuery = "INSERT INTO Comments (tweetId, userId, commentText) VALUES (@tweetId, @userId, @commentText)";
            using (SqlCommand cmd = new SqlCommand(insertQuery))
            {
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@commentText", commentText);
                Database.ExecuteQuery(cmd);
            }

             string checkQuery = "SELECT Comment FROM UserActions WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand cmd = new SqlCommand(checkQuery))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                object result = Database.ExecuteScalar(cmd);

                  if (result != null)
                {
                    int commentCount = 0;
                    if (result != null && result is int)
                    {
                        commentCount = (int)result;
                    }

                    commentCount++;
                    string updateQuery = "UPDATE UserActions SET Comment = @commentCount WHERE tweetId = @tweetId AND userId = @userId";
                    using (SqlCommand updateCmd = new SqlCommand(updateQuery))
                    {
                        updateCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        updateCmd.Parameters.AddWithValue("@userId", userId);
                        updateCmd.Parameters.AddWithValue("@commentCount", commentCount);
                        Database.ExecuteQuery(updateCmd);
                    }
                    string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Comment' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                    {
                        notifyCmd.Parameters.AddWithValue("@userId", userId);
                        notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(notifyCmd);
                    }
                }
                 else
                {
                    string insertActionQuery = "INSERT INTO UserActions (tweetId, userId, Comment) VALUES (@tweetId, @userId, 1)";
                    using (SqlCommand insertCmd = new SqlCommand(insertActionQuery))
                    {
                        insertCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        insertCmd.Parameters.AddWithValue("@userId", userId);
                        Database.ExecuteQuery(insertCmd);
                    }
                    string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Comment' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                    {
                        notifyCmd.Parameters.AddWithValue("@userId", userId);
                        notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(notifyCmd);
                    }
                }
            }
        }



        public void Save( )
        {
            string query1 = "INSERT INTO SavedTweets (userId, tweetId) VALUES (@userId, @tweetId)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                Database.ExecuteQuery(cmd);
            }
            string checkQuery = "SELECT SaveCount FROM UserActions WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery))
            {
                checkCmd.Parameters.AddWithValue("@userId", userId);
                checkCmd.Parameters.AddWithValue("@tweetId", tweetId);
                object result = Database.ExecuteScalar(checkCmd);

                Console.WriteLine("Checked UserActions table, result: " + result);

                  if (result == null)
                {

                    string query2 = "INSERT INTO UserActions (tweetId, userId, SaveCount) VALUES (@tweetId, @userId, 1)";
                    using (SqlCommand cmd = new SqlCommand(query2))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(cmd);
                    }

                    string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Save' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                    {
                        notifyCmd.Parameters.AddWithValue("@userId", userId);
                        notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(notifyCmd); Console.WriteLine("Inserted new save into notify table");


                    }
                }

                else if (result != null && result is int)
                {
                    int saveCount = (int)result;
                    saveCount = saveCount == 0 ? 1 : 0;

                    string query2 = "UPDATE UserActions SET SaveCount = @saveCount WHERE userId = @userId AND tweetId = @tweetId";
                    using (SqlCommand cmd = new SqlCommand(query2))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        cmd.Parameters.AddWithValue("@saveCount", saveCount);
                        Database.ExecuteQuery(cmd);
                    }
                    string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Save' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                    {
                        notifyCmd.Parameters.AddWithValue("@userId", userId);
                        notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(notifyCmd); Console.WriteLine("Inserted new save into notify table");


                    }
                }
            }
        }

        public void DeleteSave()
        {
              string query1 = "DELETE FROM SavedTweets WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                Database.ExecuteQuery(cmd);
            }

             string query2 = "UPDATE UserActions SET SaveCount = 0 WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand cmd = new SqlCommand(query2))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                Database.ExecuteQuery(cmd);
            }
        }


        public void Retweet( )
        {
             string checkQuery = "SELECT RetweetCount FROM UserActions WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery))
            {
                checkCmd.Parameters.AddWithValue("@userId", userId);
                checkCmd.Parameters.AddWithValue("@tweetId", tweetId);
                object result = Database.ExecuteScalar(checkCmd);

                 if (result == null)
                {
                    string query1 = "INSERT INTO UserActions (tweetId, userId, RetweetCount) VALUES (@tweetId, @userId, 1)";
                    using (SqlCommand cmd = new SqlCommand(query1))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(cmd);
                    }
                    string query2 = "INSERT INTO Retweets (userId, tweetId, originalUsername, originalProfilePic) SELECT @userId, @tweetId, T.username, U.profilePicturePath FROM Tweets T INNER JOIN Users U ON T.username = U.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand cmd = new SqlCommand(query2))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(cmd);
                    }
                    string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Retweet' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                    using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                    {
                        notifyCmd.Parameters.AddWithValue("@userId", userId);
                        notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                        Database.ExecuteQuery(notifyCmd);
                    }
                }
                else if (result != null)
                {
                    int retweetCount;
                    if (result is DBNull)  {
                        retweetCount = 1;
                    }
                    else    {
                        retweetCount = (int)result;
                        retweetCount = retweetCount == 0 ? 1 : 0;
                        if (retweetCount == 1)
                        {
                            string notifyQuery = "INSERT INTO Notify (UserId, OwnerUserId, TweetId, UserProfilePicturePath, Action) SELECT @userId, U.id, @tweetId, (SELECT profilePicturePath FROM Users WHERE id = @userId), 'Retweet' FROM Tweets T INNER JOIN Users U ON U.username = T.username WHERE T.tweetId = @tweetId";
                            using (SqlCommand notifyCmd = new SqlCommand(notifyQuery))
                            {
                                notifyCmd.Parameters.AddWithValue("@userId", userId);
                                notifyCmd.Parameters.AddWithValue("@tweetId", tweetId);
                                Database.ExecuteQuery(notifyCmd);
                            }
                        }
                    }

                    string query = "UPDATE UserActions SET RetweetCount = @retweetCount WHERE tweetId = @tweetId AND userId = @userId";
                    using (SqlCommand cmd = new SqlCommand(query))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@tweetId", tweetId);
                        cmd.Parameters.AddWithValue("@retweetCount", retweetCount);
                        Database.ExecuteQuery(cmd);
                    }

                     if (retweetCount == 0)
                    {
                        u.DeleteRetweet(userId, tweetId);
                    }
                    else
                    {
                        string query2 = "INSERT INTO Retweets (userId, tweetId, originalUsername, originalProfilePic) SELECT @userId, @tweetId, T.username, U.profilePicturePath FROM Tweets T INNER JOIN Users U ON T.username = U.username WHERE T.tweetId = @tweetId";
                        using (SqlCommand cmd = new SqlCommand(query2))
                        {
                            cmd.Parameters.AddWithValue("@userId", userId);
                            cmd.Parameters.AddWithValue("@tweetId", tweetId);
                            Database.ExecuteQuery(cmd);
                        }
                    }
                }
            }
        }
        public bool IsLiked( )
        {
             string checkQuery = "SELECT COUNT(*) FROM UserActions WHERE userId = @userId AND tweetId = @tweetId AND LikeCount>0";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery))
            {
                checkCmd.Parameters.AddWithValue("@userId", userId);
                checkCmd.Parameters.AddWithValue("@tweetId", tweetId);
                int count = (int)Database.ExecuteScalar(checkCmd);

                   return count > 0;
            }
        }
        public bool IsSaved( )
        {
             string checkQuery = "SELECT COUNT(*) FROM SavedTweets WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery))
            {
                checkCmd.Parameters.AddWithValue("@userId", userId);
                checkCmd.Parameters.AddWithValue("@tweetId", tweetId);
                int count = (int)Database.ExecuteScalar(checkCmd);

                  return count > 0;
            }
        }
        public bool IsRetweeted(  )
        {
              string checkQuery = "SELECT COUNT(*) FROM Retweets WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery))
            {
                checkCmd.Parameters.AddWithValue("@userId", userId);
                checkCmd.Parameters.AddWithValue("@tweetId", tweetId);
                int count = (int)Database.ExecuteScalar(checkCmd);

                  return count > 0;
            }
        }
 
    }
}
