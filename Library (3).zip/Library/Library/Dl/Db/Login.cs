﻿
using System;
using System.Data.SqlClient;
namespace Library
{
    public class Login
    {
        public User User { get; set; }
        public Login(User user)
        {
            User = user;
        }
        public User SignIn()
        {
            bool userExists = CheckUserExistsInDatabase();
            if (!userExists)
            {
                throw new Exception("User does not exist.");
            }
            bool passwordIsValid = ValidatePassword();
            if (!passwordIsValid)
            {
                throw new Exception("Invalid password.");
            }
            int userId = GetUserId();  
            User.UserId = userId; 
            string role = GetUserRole();
            User.SetRole(role); 
            string email = GetUserEmail();
            User.SetEmail(email); 
            string profilePicturePath = GetUserProfilePicturePath();
            User.SetProfilePicturePath(profilePicturePath); 
            string gender = GetUserGender();
            User.Setgender(gender);
            bool bt = getbt();
            User.Bluetick = bt; 
            return User;
        }

        private int GetUserId()
        {
            string query = "SELECT id FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            int userId = Convert.ToInt32(Database.ExecuteScalar(cmd));

            return userId;
        } 
        private bool CheckUserExistsInDatabase()
        {
            string query = "SELECT COUNT(*) FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            int count = Convert.ToInt32(Database.ExecuteScalar(cmd));  
            return count > 0;
        }

        private bool ValidatePassword()
        {
            string query = "SELECT password FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            string storedPassword = Convert.ToString(Database.ExecuteScalar(cmd)); 
            return User.GetPassword() == storedPassword;
        }
        private string GetUserRole()
        {
            string query = "SELECT role FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            string role = Convert.ToString(Database.ExecuteScalar(cmd)); 
            return role;
        }
        private string GetUserEmail()
        {
            string query = "SELECT email FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            string email = Convert.ToString(Database.ExecuteScalar(cmd)); 
            return email;
        }

        private string GetUserGender()
        {
            string query = "SELECT gender FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            string gender = Convert.ToString(Database.ExecuteScalar(cmd)); 
            return gender;
        }
        private string GetUserProfilePicturePath()
        {
            string query = "SELECT profilePicturePath FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            string profilePicturePath = Convert.ToString(Database.ExecuteScalar(cmd)); 
            return profilePicturePath;
        }

        private bool getbt()
        {
            string query = "SELECT bluetick FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername()); 
            int bluetick = Convert.ToInt32(Database.ExecuteScalar(cmd));
            Console.WriteLine(bluetick);
              if (bluetick == 1)
            {
                return true;
            }  return false;
        }

    }

}

