﻿
using System;
using System.Data.SqlClient;
namespace Library
{
    public class Signup
    {
        public User User { get; set; } 
        public Signup(User user)
        {
            User = user;
        } 
        public void Register()
        {
            bool usernameIsUnique = CheckUsernameIsUnique();

            if (!usernameIsUnique)
            {
                throw new Exception("Username already exists.");
            }

            if (User.GetPassword().Length < 8)
            {
                throw new Exception("Password should be at least 8 characters long.");
            }

            string role = User.GetRole();
            if (role != "admin" && role != "businessman" && role != "regular user")
            {
                throw new Exception("Role should be either 'admin', 'businessman', or 'regular user'.");
            }
            if (!User.IsValidEmail())
            { 
                throw new Exception("Invalid Email"); 
            }
            string gender = User.Getgender();
            if (gender != "Male" && gender != "Female" && gender != "Other")
            {
                throw new Exception("Gender should be either 'Male', 'Female', or 'Other'.");
            }
            StoreUserDataInDatabase();
        }


        private bool CheckUsernameIsUnique()
        {
            string username = User.GetUsername();
            string query = "SELECT COUNT(*) FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", username);
            int count = Convert.ToInt32(Database.ExecuteScalar(cmd)); 
            return count == 0;
        }

        private void StoreUserDataInDatabase()
        {
            string query = "INSERT INTO Users (username, password, role, email, gender) VALUES (@username, @password, @role, @email, @gender)";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", User.GetUsername());
            cmd.Parameters.AddWithValue("@password", User.GetPassword());
            cmd.Parameters.AddWithValue("@role", User.GetRole());
            cmd.Parameters.AddWithValue("@email", User.GetEmail());
            cmd.Parameters.AddWithValue("@gender", User.Getgender()); 
            Database.ExecuteQuery(cmd);
        }

    }
}


