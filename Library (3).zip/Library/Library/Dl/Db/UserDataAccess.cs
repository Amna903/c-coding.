﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
namespace Library
{
    public class TweetManagement
    {
        public List<Mb> GetMessages(User user1, User user2)
        {
            List<Mb> messages = new List<Mb>();

             string query = "SELECT * FROM Messages WHERE (SenderUserId = @User1Id AND ReceiverUserId = @User2Id) OR (SenderUserId = @User2Id AND ReceiverUserId = @User1Id)";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                 cmd.Parameters.AddWithValue("@User1Id", user1.UserId);
                cmd.Parameters.AddWithValue("@User2Id", user2.UserId);

                  DataTable dt = Database.ExecuteQueryAndReturnDataTable(cmd);

                 foreach (DataRow row in dt.Rows)
                {
                    Mb message = new Mb();
                    message.SetSender(user1.UserId == (int)row["SenderUserId"] ? user1 : user2);
                    message.SetReceiver(user1.UserId == (int)row["ReceiverUserId"] ? user1 : user2);
                    message.SetMsg((string)row["MessageContent"]);
                    messages.Add(message);
                }
            }

            return messages;
        }


        public void InsertMessage(Mb message)
        {
              string query = "INSERT INTO Messages (SenderUserId, ReceiverUserId, MessageContent, SenderUsername, ReceiverUsername) VALUES (@SenderUserId, @ReceiverUserId, @MessageContent, @SenderUsername, @ReceiverUsername)";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                 cmd.Parameters.AddWithValue("@SenderUserId", message.GetSender().UserId);
                cmd.Parameters.AddWithValue("@ReceiverUserId", message.GetReceiver().UserId);
                cmd.Parameters.AddWithValue("@MessageContent", message.GetMsg());
                cmd.Parameters.AddWithValue("@SenderUsername", message.GetSender().GetUsername());
                cmd.Parameters.AddWithValue("@ReceiverUsername", message.GetReceiver().GetUsername());

                 Database.ExecuteQuery(cmd);
            }
        }


        public void SaveTweet(string username, string tweetText)
        {
            string query = "INSERT INTO Tweets (username, tweetText) VALUES (@username, @tweetText)";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@tweetText", tweetText);

                  Database.ExecuteQuery(cmd);
            }
        }
        public List<Tweet> GetAllTweets()
        {
            string query = "SELECT Users.id, Users.profilePicturePath, Users.bluetick, Tweets.tweetId, Tweets.username, Tweets.tweetText FROM Tweets INNER JOIN Users ON Tweets.username = Users.username";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                DataTable dataTable = Database.ExecuteQueryAndReturnDataTable(cmd);
                List<Tweet> tweets = new List<Tweet>();

                foreach (DataRow row in dataTable.Rows)
                {
                    Tweet tweet = new Tweet()
                    {
                        TweetId = Convert.ToInt32(row["tweetId"]),
                        Username = row["username"].ToString(),
                        TweetText = row["tweetText"].ToString(),
                        ProfilePicturePath = row["profilePicturePath"].ToString(),
                        bluetick = Convert.ToInt32(row["bluetick"]) == 1
                    };
                    tweets.Add(tweet);
                }

                return tweets;
            }
        }

        public void DeleteRetweet(int userId, int tweetId)
        {
             string deleteRetweetsSql = "DELETE FROM Retweets WHERE userId = @userId AND tweetId = @tweetId";
            using (SqlCommand cmd = new SqlCommand(deleteRetweetsSql))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                Database.ExecuteQuery(cmd);
            }
        }
        public List<Tweet> GetSavedTweets(int userId)
        {
            List<Tweet> savedTweets = new List<Tweet>();

            string query = "SELECT st.TweetId, t.username, t.tweetText, u.profilePicturePath FROM SavedTweets st INNER JOIN Tweets t ON st.TweetId = t.tweetId INNER JOIN Users u ON t.username = u.username WHERE st.UserId = @UserId";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@UserId", userId);

                DataTable dt = Database.ExecuteQueryAndReturnDataTable(cmd);
                foreach (DataRow row in dt.Rows)
                {
                    int tweetId = (int)row["TweetId"];
                    string username = row["username"].ToString();
                    string tweetText = row["tweetText"].ToString();
                    string profilePicturePath = row["profilePicturePath"].ToString();

                     Tweet tweet = new Tweet { TweetId = tweetId, Username = username, TweetText = tweetText, ProfilePicturePath = profilePicturePath };
                    savedTweets.Add(tweet);
                }
            }

            return savedTweets;
        }



        public DataTable GetTweetsByUser(string username)
        {
            string query = "SELECT Tweets.*, Users.profilePicturePath FROM Tweets INNER JOIN Users ON Tweets.username = Users.username WHERE Tweets.username = @username";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@username", username);
   return Database.ExecuteQueryAndReturnDataTable(cmd);
            }
        }

        public DataTable GetTweetsAndRetweetsByUser(string username)
        {

            string query = @"
SELECT T.tweetId, T.username, T.tweetText, U.profilePicturePath
FROM Tweets T
INNER JOIN Users U ON T.username = U.username
WHERE T.username = @username
UNION ALL
SELECT R.tweetId, T.username, T.tweetText, U.profilePicturePath
FROM Retweets R
INNER JOIN Tweets T ON R.tweetId = T.tweetId
INNER JOIN Users U ON T.username = U.username
WHERE R.userId = (SELECT id FROM Users WHERE username = @username)";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@username", username);
                return Database.ExecuteQueryAndReturnDataTable(cmd);
            }
        }
      
        public void DeleteTweet(int userId, int tweetId)
        {
            string ownerQuery = "SELECT U.id FROM Users U INNER JOIN Tweets T ON U.username = T.username WHERE T.TweetId = @tweetId";
            int ownerId;
            using (SqlCommand cmd = new SqlCommand(ownerQuery))
            {
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                object result = Database.ExecuteScalar(cmd);
                if (result != null)
                {
                    ownerId = Convert.ToInt32(result);
                }
                else
                {
                    Console.WriteLine($"No tweet found with ID {tweetId}");
                    return;
                }
            }

             string roleQuery = "SELECT Role FROM Users WHERE id = @userId";
            string role;
            using (SqlCommand cmd = new SqlCommand(roleQuery))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                object result = Database.ExecuteScalar(cmd);
                if (result != null)
                {
                    role = result.ToString();
                }
                else
                {
                    Console.WriteLine($"No user found with ID {userId}");
                    return;
                }
            }
            string deleteSavedTweetsSql = $"DELETE FROM SavedTweets WHERE tweetId = {tweetId}";
            using (SqlCommand cmd = new SqlCommand(deleteSavedTweetsSql))
            {
                Database.ExecuteQuery(cmd);
            }

             string deleteRetweetsSql = $"DELETE FROM Retweets WHERE tweetId = {tweetId}";
            using (SqlCommand cmd = new SqlCommand(deleteRetweetsSql))
            {
                Database.ExecuteQuery(cmd);
            }

 string sql = $"DELETE FROM UserActions WHERE tweetId = {tweetId}";
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                Database.ExecuteQuery(cmd);
            }

             string deleteCommentsSql = $"DELETE FROM Comments WHERE tweetId = {tweetId}";
            using (SqlCommand cmd = new SqlCommand(deleteCommentsSql))
            {
                Database.ExecuteQuery(cmd);
            }

             string query = "DELETE FROM Tweets WHERE tweetId = @tweetId";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                Database.ExecuteQuery(cmd);
            }

             if (role == "admin")
            {
                string actionQuery = "INSERT INTO AdminActions (UserId, ActionPerformed, ActionTime) VALUES (@userId, 'Deleted tweet', GETDATE())";
                using (SqlCommand cmd = new SqlCommand(actionQuery))
                {
                    cmd.Parameters.AddWithValue("@userId", ownerId);
                    Database.ExecuteQuery(cmd);
                }
            }
        }

    }

    public class CommentManagement
    {
        public List<string> FetchCommentsFromDatabase(int tweetId)
        {
            string query = "SELECT commentText FROM Comments WHERE tweetId = @tweetId";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                DataTable dataTable = Database.ExecuteQueryAndReturnDataTable(cmd);
                List<string> comments = new List<string>();

                foreach (DataRow row in dataTable.Rows)
                {
                    comments.Add(row["commentText"].ToString());
                }

                return comments;
            }
        }
        public int GetUserIdFromComment(string comment)
        {
            string query = "SELECT userId FROM Comments WHERE commentText = @comment";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@comment", comment);
                int userId = Convert.ToInt32(Database.ExecuteScalar(cmd));
                return userId;
            }
        }

    }

    public class NotificationManagement
    {
        public List<string> GetNotifications(int userId)
        {
            List<string> notifications = new List<string>();
            string query = @"
        SELECT U.username, N.UserProfilePicturePath, N.Action, T.tweetText, N.ActionDate, 'user' as UserType
        FROM Notify N 
        INNER JOIN Users U ON N.UserId = U.id 
        INNER JOIN Tweets T ON N.TweetId = T.tweetId 
        WHERE N.OwnerUserId = @userId
        UNION ALL
        SELECT 'Admin', '', AA.ActionPerformed, '', AA.ActionTime, 'admin' as UserType
        FROM AdminActions AA
        WHERE AA.UserId = @userId
        ORDER BY ActionDate DESC";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                SqlDataReader reader = Database.ExecuteReader(cmd);

                while (reader.Read())
                {
                    string actionUsername = reader.GetString(0);
                    string userProfilePicturePath = reader.IsDBNull(1) ? "C:\\twitter1\\Twitter\\Resources\\06ff5d234a2bb4856aa4d9fe838b863b-removebg-preview.png" : reader.GetString(1); // Check if the UserProfilePicturePath is null
                    string action = reader.GetString(2);
                    string tweetContent = reader.GetString(3);
                    DateTime actionDate = reader.GetDateTime(4);
                    string userType = reader.GetString(5);

                    // Get the first 20 words of the tweet content
                    string[] words = tweetContent.Split(' ');
                    string shortTweetContent = string.Join(" ", words.Take(20));

                    string notification;
                    if (userType == "admin")
                    {
                        notification = $"Admin has performed this action: {action} on {actionDate}";
                    }
                    else
                    {
                        notification = $"User {actionUsername} ({userProfilePicturePath}) has {action} your tweet: \"{shortTweetContent}...\" on {actionDate}";
                    }
                    notifications.Add(notification);
                }
            }
            return notifications;
        }
        public void DeleteUserNotifications(int userId)
        {
            string query = "DELETE FROM Notify WHERE OwnerUserId = @userId";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@userId", userId);

                 Database.ExecuteQuery(cmd);
            }
        }
    }

    public class AdminActions
    {
        public void Admin(string username, string reportAction)
        {
             string userQuery = "SELECT id FROM Users WHERE Username = @username";
            int userId;
            using (SqlCommand cmd = new SqlCommand(userQuery))
            {
                cmd.Parameters.AddWithValue("@username", username);
                object result = Database.ExecuteScalar(cmd);
                if (result == null)
                {
                    throw new Exception("User not found");
                }
                userId = Convert.ToInt32(result);
            }

             string actionQuery = "INSERT INTO AdminActions (UserId, ActionPerformed, ActionTime) VALUES (@userId, @reportAction, GETDATE())";
            using (SqlCommand cmd = new SqlCommand(actionQuery))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@reportAction", reportAction);
                Database.ExecuteQuery(cmd);
            }
        }

    }

 }