﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Library
{
    public class Database
    {
        private static SqlConnection con { get; set; }
        public static void Connect(string user, string password)
        {
            con = new SqlConnection();
            try
            {
                con.ConnectionString = "Data Source=10.5.116.14;Initial Catalog=twitter;User ID=sa;Password=VeryStr0ngP@ssw0rd";
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to connect due to " + e.ToString());
                con = null;
                throw;
            }
        }

        public static object ExecuteScalar(SqlCommand cmd)
        {
            object result = null;
            try
            {
                if (con == null || con.State != System.Data.ConnectionState.Open)
                {
                    throw new InvalidOperationException("Database connection is not open.");
                }

                cmd.Connection = con;
                result = cmd.ExecuteScalar();
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to execute scalar due to " + e.ToString());
                throw;
            }
            return result;
        }

        public static void ExecuteQuery(SqlCommand cmd)
        {
            try
            {
                if (con == null || con.State != System.Data.ConnectionState.Open)
                {
                    throw new InvalidOperationException("Database connection is not open.");
                }

                cmd.Connection = con;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to execute query due to " + e.ToString());
                throw;
            }
        }
        public static SqlDataReader ExecuteReader(SqlCommand cmd)
        {
            SqlDataReader reader = null;
            try
            {
                if (con == null || con.State != System.Data.ConnectionState.Open)
                {
                    throw new InvalidOperationException("Database connection is not open.");
                }

                cmd.Connection = con;
                reader = cmd.ExecuteReader();
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to execute reader due to " + e.ToString());
                throw;
            }

            return reader;
        }
        public static DataTable ExecuteQueryAndReturnDataTable(SqlCommand cmd)
        {
            DataTable dt = new DataTable();

            try
            {
                if (con == null || con.State != System.Data.ConnectionState.Open)
                {
                    throw new InvalidOperationException("Database connection is not open.");
                }

                cmd.Connection = con;
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to execute query due to " + e.ToString());
                throw;
            }

            return dt;
        }

    }
}
