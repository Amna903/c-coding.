﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Library.Db
{
    public class UserManagement
    {
        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();

            string query = "SELECT * FROM Users";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                 DataTable dtUsers = Database.ExecuteQueryAndReturnDataTable(cmd);

                 foreach (DataRow row in dtUsers.Rows)
                {
                    User user = new User();
                    user.UserId = Convert.ToInt32(row["id"]);
                    user.ProfilePicturePath = Convert.ToString(row["profilePicturePath"]);
                    user.Setgender(Convert.ToString(row["gender"]));
                    user.SetEmail(Convert.ToString(row["email"]));
                     user.SetUsername(Convert.ToString(row["username"]));
                    user.SetPassword(Convert.ToString(row["password"]));
                    user.SetRole(Convert.ToString(row["role"]));
                      users.Add(user);
                }

            }

            return users;
        }


        public void UpdateUserData(User user, string originalUsername)
        { 
             string queryUser = "UPDATE Users SET username = @newUsername, password = @password, role = @role, email = @email, gender = @gender WHERE username = @originalUsername";
            using (SqlCommand cmd = new SqlCommand(queryUser))// Assuming Database.Connection is your SqlConnection
            {
                cmd.Parameters.AddWithValue("@originalUsername", originalUsername);
                cmd.Parameters.AddWithValue("@newUsername", user.GetUsername());
                cmd.Parameters.AddWithValue("@password", user.GetPassword());
                cmd.Parameters.AddWithValue("@role", user.GetRole());
                cmd.Parameters.AddWithValue("@email", user.GetEmail());
                cmd.Parameters.AddWithValue("@gender", user.Getgender());
                 Database.ExecuteQuery(cmd);
            }
        }

        public DataTable GetUsersLike(string username)
        {
            string query = "SELECT username, profilePicturePath FROM Users WHERE username LIKE @username";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@username", "%" + username + "%");

                  return Database.ExecuteQueryAndReturnDataTable(cmd);
            }
        }
        public string GetProfilePicturePath(int userId)
        {
            string query = "SELECT profilePicturePath FROM Users WHERE id = @userId";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                string profilePicturePath = Convert.ToString(Database.ExecuteScalar(cmd));
                return profilePicturePath;
            }
        }

        public void UpdateProfilePicturePath(string username, string profilePicturePath)
        {
            string query = "UPDATE Users SET profilePicturePath = @profilePicturePath WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@profilePicturePath", profilePicturePath);
            Database.ExecuteQuery(cmd);
        }

        public bool IsUsernameUnique(string username)
        {
            string query = "SELECT COUNT(*) FROM Users WHERE username = @username";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@username", username);
            int count = (int)Database.ExecuteScalar(cmd);
            return count == 0;
        }
        public void UpdateBluetick(string username)
        {
            string commandText = "UPDATE Users SET bluetick = 1 WHERE username = @username";
            using (SqlCommand cmd = new SqlCommand(commandText))
            {
                cmd.Parameters.AddWithValue("@username", username);
                Database.ExecuteQuery(cmd);
            }
        }

        public void DeleteUser(int userId)
        {
             string getUsernameQuery = "SELECT username FROM Users WHERE id = @userId";
            string username;
            using (SqlCommand cmd = new SqlCommand(getUsernameQuery))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                username = (string)Database.ExecuteScalar(cmd);    }
            string queryRetweets = "DELETE FROM Retweets WHERE userId = @userId";
            using (SqlCommand cmd = new SqlCommand(queryRetweets))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                Database.ExecuteQuery(cmd);
            }string queryComments = "DELETE FROM Comments WHERE userId = @userId";
            using (SqlCommand cmd = new SqlCommand(queryComments))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                Database.ExecuteQuery(cmd);
            }

             string querySavedTweets = "DELETE FROM SavedTweets WHERE userId = @userId";
            using (SqlCommand cmd = new SqlCommand(querySavedTweets))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                Database.ExecuteQuery(cmd);
            }
             string query3 = "DELETE FROM UserActions WHERE UserId = @userId";
            using (SqlCommand cmd = new SqlCommand(query3))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                Database.ExecuteQuery(cmd);
            }  
 string query1 = "DELETE FROM AdminActions WHERE UserId = @userId";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                Database.ExecuteQuery(cmd);
            }

             string query2 = "DELETE FROM Tweets WHERE username = @username";
            using (SqlCommand cmd = new SqlCommand(query2))
            {
                cmd.Parameters.AddWithValue("@username", username);
                Database.ExecuteQuery(cmd);
            }
          

             string query9 = "DELETE FROM Users WHERE id = @userId";
            using (SqlCommand cmd = new SqlCommand(query9))
            {
                cmd.Parameters.AddWithValue("@userId", userId);
                Database.ExecuteQuery(cmd);
            }
        }


    }


}
