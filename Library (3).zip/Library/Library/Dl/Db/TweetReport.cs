﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Library
{
    public class TweetReporr
    {



        public class TweetReport
        {
            public string TweetText { get; set; }
            public int TotalLikes { get; set; }
            public int TotalComments { get; set; }
            public int TotalSaves { get; set; }
            public int TotalRetweets { get; set; }
        }
        public Tuple<string, Tweet> GetMostLikedTweet()
        {
            Tweet tweet = new Tweet();
            string query = @"SELECT TOP 1 T.tweetId, T.tweetText, U.username, U.profilePicturePath, SUM(UA.LikeCount) as TotalLikes 
FROM UserActions UA 
INNER JOIN Users U ON UA.userId = U.id 
INNER JOIN Tweets T ON U.username = T.username 
GROUP BY T.tweetId, T.tweetText, U.username, U.profilePicturePath 
ORDER BY TotalLikes DESC";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                SqlDataReader reader = null;
                try
                {
                    reader = Database.ExecuteReader(cmd);
                    if (reader.Read())
                    {
                        tweet.TweetId = Convert.ToInt32(reader["TweetId"]);
                        tweet.TweetText = reader["TweetText"].ToString();
                        tweet.Username = reader["username"].ToString();
                        tweet.ProfilePicturePath = reader["ProfilePicturePath"].ToString();

 if (string.IsNullOrEmpty(tweet.ProfilePicturePath))
                        { 
                            tweet.ProfilePicturePath = "C:\\twitter1\\Twitter\\Resources\\06ff5d234a2bb4856aa4d9fe838b863b-removebg-preview.png";
                        }
                    }
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
                string statement = $"The most liked tweet is '{tweet.TweetText}' by {tweet.Username}.";
                return new Tuple<string, Tweet>(statement, tweet); Console.WriteLine("Liked successfully");
            }
        }

        public Tuple<string, Tweet> GetMostSavedTweet()
        {
            Tweet tweet = new Tweet();
            string query = @"SELECT TOP 1 T.tweetId, T.tweetText, U.username, U.profilePicturePath, SUM(UA.SaveCount) as TotalSaves 
FROM UserActions UA 
INNER JOIN Users U ON UA.userId = U.id 
INNER JOIN Tweets T ON U.username = T.username 
GROUP BY T.tweetId, T.tweetText, U.username, U.profilePicturePath 
ORDER BY TotalSaves DESC


";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                SqlDataReader reader = Database.ExecuteReader(cmd);
                if (reader.Read())
                {
                    tweet.Username = reader["username"].ToString();
                    tweet.TweetText = reader["TweetText"].ToString();
                    tweet.ProfilePicturePath = reader["ProfilePicturePath"].ToString();
                     
                    if (string.IsNullOrEmpty(tweet.ProfilePicturePath))
                    { 
                        tweet.ProfilePicturePath = "C:\\twitter1\\Twitter\\Resources\\06ff5d234a2bb4856aa4d9fe838b863b-removebg-preview.png";
                    }
                }
                reader.Close();
            }
            string statement = $"The most saved tweet is '{tweet.TweetText}' by {tweet.Username}.";
            return new Tuple<string, Tweet>(statement, tweet);
        }
        public Tuple<string, Tweet> GetMostCommentedTweet()
        {
            Tweet tweet = new Tweet();
            string query = @"SELECT TOP 1 T.tweetId, T.tweetText, U.username, U.profilePicturePath, SUM(UA.Comment) as TotalComments 
FROM UserActions UA 
INNER JOIN Users U ON UA.userId = U.id 
INNER JOIN Tweets T ON U.username = T.username 
GROUP BY T.tweetId, T.tweetText, U.username, U.profilePicturePath 
ORDER BY TotalComments DESC


";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                SqlDataReader reader = Database.ExecuteReader(cmd);
                if (reader.Read())
                {
                    tweet.Username = reader["username"].ToString();
                    tweet.TweetText = reader["TweetText"].ToString();
                    tweet.ProfilePicturePath = reader["ProfilePicturePath"].ToString();
                     
                    if (string.IsNullOrEmpty(tweet.ProfilePicturePath))
                    { 
                        tweet.ProfilePicturePath = "C:\\twitter1\\Twitter\\Resources\\06ff5d234a2bb4856aa4d9fe838b863b-removebg-preview.png";
                    }
                }
                reader.Close();
            }
            string statement = $"The most commented tweet is '{tweet.TweetText}' by {tweet.Username}.";
            return new Tuple<string, Tweet>(statement, tweet);
        }

        public Tuple<string, Tweet> GetMostRetweetedTweet()
        {
            Tweet tweet = new Tweet();
            string query = @"

SELECT TOP 1 T.tweetId, T.tweetText, U.username, U.profilePicturePath, SUM(UA.RetweetCount) as TotalRetweets 
FROM UserActions UA 
INNER JOIN Users U ON UA.userId = U.id 
INNER JOIN Tweets T ON U.username = T.username 
GROUP BY T.tweetId, T.tweetText, U.username, U.profilePicturePath 
ORDER BY TotalRetweets DESC

";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                SqlDataReader reader = Database.ExecuteReader(cmd);
                if (reader.Read())
                {
                    tweet.Username = reader["username"].ToString();
                    tweet.TweetText = reader["TweetText"].ToString();
                    tweet.ProfilePicturePath = reader["ProfilePicturePath"].ToString();
                     
                    if (string.IsNullOrEmpty(tweet.ProfilePicturePath))
                    { 
                        tweet.ProfilePicturePath = "C:\\twitter1\\Twitter\\Resources\\06ff5d234a2bb4856aa4d9fe838b863b-removebg-preview.png";
                    }
                }
                reader.Close();
            }
            string statement = $"The most retweeted tweet is '{tweet.TweetText}' by {tweet.Username}.";
            return new Tuple<string, Tweet>(statement, tweet);
        }

        public TweetReport GetTweetReport(int tweetId)
        {
            TweetReport reportData = new TweetReport();

            string query = "SELECT T.TweetText, SUM(UA.LikeCount) as TotalLikes, SUM(UA.Comment) as TotalComments, SUM(UA.SaveCount) as TotalSaves, SUM(UA.RetweetCount) as TotalRetweets FROM UserActions UA INNER JOIN Tweets T ON UA.TweetId = T.TweetId WHERE UA.TweetId = @tweetId GROUP BY T.TweetText";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@tweetId", tweetId);
                SqlDataReader reader = Database.ExecuteReader(cmd);

                if (reader.Read())
                {
                    reportData.TweetText = reader["TweetText"].ToString();
                    reportData.TotalLikes = reader["TotalLikes"] == DBNull.Value ? 0 : Convert.ToInt32(reader["TotalLikes"]);
                    Console.WriteLine(reportData.TotalLikes); reportData.TotalComments = reader["TotalComments"] == DBNull.Value ? 0 : Convert.ToInt32(reader["TotalComments"]);
                    reportData.TotalSaves = reader["TotalSaves"] == DBNull.Value ? 0 : Convert.ToInt32(reader["TotalSaves"]);
                    reportData.TotalRetweets = reader["TotalRetweets"] == DBNull.Value ? 0 : Convert.ToInt32(reader["TotalRetweets"]);
                }

                reader.Close();
            }

            return reportData;
        }
        public List<string> GetTrendingTopics()
        {
            Dictionary<string, int> wordCounts = new Dictionary<string, int>();
            HashSet<string> commonWords = new HashSet<string> { "the", "is", "and", "or", "a", "an", "in", "at", "of", "for" }; // Add more common words as needed

            string query = "SELECT TweetText FROM Tweets";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                SqlDataReader reader = Database.ExecuteReader(cmd);
                while (reader.Read())
                {
                    string tweetText = reader["TweetText"].ToString();
                    string[] words = tweetText.Split(' ');
                    foreach (string word in words)
                    {
                        if (!commonWords.Contains(word.ToLower()))
                        {
                            if (wordCounts.ContainsKey(word))
                            {
                                wordCounts[word]++;
                            }
                            else
                            {
                                wordCounts[word] = 1;
                            }
                        }
                    }
                }
                reader.Close();
            }

            List<string> trendingTopics = wordCounts.OrderByDescending(x => x.Value).Take(5).Select(x => x.Key).ToList();
            return trendingTopics;
        }



    }
}
