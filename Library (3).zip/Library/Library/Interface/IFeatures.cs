﻿namespace Library
{

    public interface IFeatures
    {
        void Retweet();
        void Save();
        void Like();
         
        void Comment(string comment);
    }
}



