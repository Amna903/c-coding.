﻿using System;

namespace Library
{
    public class User
    {
        public int UserId { get; set; }
        public bool Bluetick { get; set; }
        public string ProfilePicturePath { get; set; }
        [Newtonsoft.Json.JsonProperty]
        protected string username;

        [Newtonsoft.Json.JsonProperty]
        protected string role;

        [Newtonsoft.Json.JsonProperty]
        protected string password;

        [Newtonsoft.Json.JsonProperty]
        protected string email;

        [Newtonsoft.Json.JsonProperty]
        protected string gender;
        public User()
        {
        }
        public string Getgender()
        {
            return gender;
        }

        public void Setgender(string value)
        {
            gender = value;
        }
        public string GetEmail()
        {
            return email;
        }

        public void SetEmail(string value)
        {
            email = value;
        }
        public string GetUsername()
        {
            return username;
        }

        public void SetUsername(string value)
        {
            username = value;
        }

        public string GetRole()
        {
            return role;
        }

        public void SetRole(string value)
        {
            role = value;
        }

        public string GetPassword()
        {
            return password;
        }

        public void SetPassword(string value)
        {
            password = value;
        }
        public bool IsValidEmail()
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return System.Text.RegularExpressions.Regex.IsMatch(email,
                       @"^[^@\s]+@[^@\s]+\.[^@\s]+$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid email format: " + ex.Message);
            }
        }
             public User(Newtonsoft.Json.Linq.JObject jObject)
            {
            UserId = (int)jObject["UserId"];
            Bluetick = (bool)jObject["Bluetick"];
            ProfilePicturePath = (string)jObject["ProfilePicturePath"];
            SetUsername((string)jObject["username"]);
            SetRole((string)jObject["role"]);
            SetPassword((string)jObject["password"]);
            SetEmail((string)jObject["email"]);
            Setgender((string)jObject["gender"]);
        }
        

        public string GetProfilePicturePath()
        {
            if (string.IsNullOrEmpty(ProfilePicturePath))
            {
                if (Getgender() == "Female")
                {
                    return "C:\\c#\\Twitter\\Twitter\\Resources\\06ff5d234a2bb4856aa4d9fe838b863b-removebg-preview.png";
                }
                else if (Getgender() == "Male")
                {
                    return "C:\\c#\\Twitter\\Twitter\\Resources\\9e21919d3c6d41b442690893ce461ce6-removebg-preview.png";
                }
                else if (Getgender() == "Other")
                {
                    return "C:\\c#\\Twitter\\Twitter\\Resources\\150fa8800b0a0d5633abc1d1c4db3d87-removebg-preview.png";
                }
            }
            else
            {
                return ProfilePicturePath;
            }

            return "C:\\c#\\Twitter\\Twitter\\Resources\\150fa8800b0a0d5633abc1d1c4db3d87-removebg-preview.png";

        }
        public void SetProfilePicturePath(string path)
        {
            ProfilePicturePath = path;
        }


    }
}

