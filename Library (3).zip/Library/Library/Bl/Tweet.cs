﻿namespace Library
{
    public class Tweet
    {
        public int TweetId { get; set; }
        public bool bluetick { get; set; }
        public string Username { get; set; }
        public string TweetText { get; set; }
        public string ProfilePicturePath { get; set; }
    }
}
