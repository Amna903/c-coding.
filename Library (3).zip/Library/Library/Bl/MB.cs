﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Mb
    {

      
            private User _sender;
            public User GetSender() { return _sender; }
            public void SetSender(User value) { _sender = value; }

            private User _receiver;
            public User GetReceiver() { return _receiver; }
            public void SetReceiver(User value) { _receiver = value; }

            private string _msg;
            public string GetMsg() { return _msg; }
            public void SetMsg(string value) { _msg = value; }



          
    }
}
