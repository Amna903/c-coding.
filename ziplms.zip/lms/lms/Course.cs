﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lms
{
    internal class Course
    {
        public string conm;
        public int coid;
        public int coch;

        public Course(string cname, int cid, int ch)
        {
            conm = cname;
            coid = cid;
            coch = ch;
        }
    }
}
