﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lms
{
    internal class Name
    {
        
            public string name;
            public int ps;
            public string id;

            public Name(string sname, int sps, string sid)
            {
                name = sname;
                ps = sps;
                id = sid;
            }
        
    }
}
