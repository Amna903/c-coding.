﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lms
{
    internal class Tch
    {
        public string sco;
        public int sch;
        public int stid;

        public Tch(string sname, int sps, int sid)
        {
            sco = sname;
            sch = sps;
            stid = sid;
        }
    }
}
