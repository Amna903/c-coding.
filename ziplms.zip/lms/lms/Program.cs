﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Xml.Linq;

namespace lms
{
    internal class Program
    {


        static void Main(string[] args)
        {
            string cname = ""; int cid = 0; int ch = 0;
            int opt = 0;
            string sname = "";
            int sps = 0;
            string sid = "";
            List<Name> name = new List<Name>();
            List<Course> course = new List<Course>();
            List<Tch> tch = new List<Tch>();
            int b = 0;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("UNIVERSITY OF ENGINEERING AND TECHNOLOGY");
                Console.WriteLine("1. Sign In");
                Console.WriteLine("2. Sign Up");
                Console.WriteLine("3. Exit");
                Console.WriteLine("Enter option no: ");
                opt = int.Parse(Console.ReadLine());

                switch (opt)
                {
                    case 1:
                        if (signin(name, ref sname, ref sps, ref sid))
                        {
                            Console.WriteLine("Sign in successful.");
                            if (sid == "student")
                            {
                                while (true)
                                {
                                    Console.Clear();
                                    Console.WriteLine("UNIVERSITY OF ENGINEERING AND TECHNOLOGY");
                                    student(ref opt);
                                    if (opt == 1)
                                    {
                                        opt1_student(course, tch, cid, ch); Console.ReadKey();
                                    }
                                    if (opt == 2)
                                    {
                                        opt2_student(tch); Console.ReadKey();
                                    }
                                    if (opt == 3)
                                    {
                                        opt3_student(tch); Console.ReadKey();
                                    }
                                    if (opt == 4)
                                    {
                                        break;
                                    }
                                }
                            }
                            if (sid == "teacher")
                            {
                                while (true)
                                {
                                    Console.Clear();
                                    Console.WriteLine("UNIVERSITY OF ENGINEERING AND TECHNOLOGY");
                                    teacher(ref opt);
                                    if (opt == 1)
                                    {
                                        opt1(course, ref cname, ref cid, ref ch); Console.ReadKey();
                                    }
                                    if (opt == 2)
                                    {
                                        opt2(course); Console.ReadKey();
                                    }
                                    if (opt == 3)
                                    {
                                        opt3(course); Console.ReadKey();
                                    }
                                    if (opt == 4)
                                    {
                                        opt4(course); Console.ReadKey();
                                    }
                                    if (opt == 5)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid username or password.");
                        }
                        break;
                    case 2:
                        signup(name, ref sname, ref sps, ref sid);
                        Console.WriteLine("Sign up successful.");
                        break;
                    case 3:
                        Console.WriteLine("Exiting...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        static bool signin(List<Name> name, ref string sname, ref int sps, ref string sid)
        {
            Console.WriteLine("Username: ");
            sname = Console.ReadLine();

            Console.WriteLine("Password: ");
            sps = int.Parse(Console.ReadLine());

            foreach (Name user in name)
            {
                if (user.name == sname && user.ps == sps)
                {
                    sid = user.id;
                    return true;
                }
            }

            return false;
        }

        static void signup(List<Name> name, ref string sname, ref int sps, ref string sid)
        {
            Console.WriteLine("Username: ");
            sname = Console.ReadLine();

            Console.WriteLine("Password: ");
            sps = int.Parse(Console.ReadLine());

            Console.WriteLine("Role: ");
            sid = Console.ReadLine();

            name.Add(new Name(sname, sps, sid));
        }
        static void student(ref int opt)
        {
            Console.WriteLine("1.Add Course");
            Console.WriteLine("2.Remove Course");
            Console.WriteLine("3.View Course");
            Console.WriteLine("Enter option no(4 for exit): ");
            opt=int.Parse(Console.ReadLine());
        }
        static void teacher(ref int opt)
        {
            Console.WriteLine("1.Add Course");
            Console.WriteLine("2.Remove Course");
            Console.WriteLine("3.Update Course");
            Console.WriteLine("4.View Courses");
            Console.WriteLine("Enter option no(5 for exit): ");
            opt = int.Parse(Console.ReadLine());
        }

        static void opt4(List<Course> course)
        {
            Console.WriteLine("Courses: ");
            foreach (Course c in course)
            {
                Console.WriteLine($"Course Name: {c.conm}, Course ID: {c.coid}, Credit Hours: {c.coch}");
            }
        }

        static void opt1(List<Course> course,ref string cname, ref int cid,ref int ch)
        {
            Console.WriteLine("Enter Course Name: ");
            cname = Console.ReadLine();
            Console.WriteLine("Enter Course id: ");
           cid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Credit hour: ");
            ch= int.Parse(Console.ReadLine());
            course.Add(new Course(cname, cid, ch));
        }
        static void opt2(List<Course> course)
        {
            Console.WriteLine("Enter Course Name: ");
            string cname = Console.ReadLine();

            Course courseToRemove = course.Find(c => c.conm == cname);
            if (courseToRemove != null)
            {
                course.Remove(courseToRemove);
                Console.WriteLine("Course removed successfully.");
            }
            else
            {
                Console.WriteLine("Course not found.");
            }
        }
        static void opt3(List<Course> course)
        {
            Console.WriteLine("Enter Course Name to Update: ");
            string cname = Console.ReadLine();

            Course courseToUpdate = course.Find(c => c.conm == cname);
            if (courseToUpdate != null)
            {
                Console.WriteLine("What do you want to update? (1. Course Name, 2. Course id, 3. Credit hour)");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter New Course Name: ");
                        string newCname = Console.ReadLine();
                        courseToUpdate.conm = newCname;
                        break;
                    case 2:
                        Console.WriteLine("Enter New Course id: ");
                        int newCid = int.Parse(Console.ReadLine());
                        courseToUpdate.coid = newCid;
                        break;
                    case 3:
                        Console.WriteLine("Enter New Credit hour: ");
                        int newCh = int.Parse(Console.ReadLine());
                        courseToUpdate.coch = newCh;
                        break;
                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }

                Console.WriteLine("Course updated successfully.");
            }
            else
            {
                Console.WriteLine("Course not found.");
            }
        }

        static void opt1_student(List<Course> course, List<Tch> tch, int cid, int ch)
        {
            Console.WriteLine("Courses: ");
            foreach (Course c in course)
            {
                Console.WriteLine($"Course Name: {c.conm}, Course ID: {c.coid}, Credit Hours: {c.coch}");
            }

            Console.WriteLine("Enter Course Name to Add: ");
            string cnameToAdd = Console.ReadLine();

            Course courseToAdd = course.Find(c => c.conm == cnameToAdd);
            if (courseToAdd == null)
            {
                Console.WriteLine("Course not found.");
            }
            else
            {
                tch.Add(new Tch(cnameToAdd, courseToAdd.coid, courseToAdd.coch));
                Console.WriteLine("Course added successfully.");
            }
        }


        static void opt2_student(List<Tch> tch)
        {
            Console.WriteLine("Enter Course Name to Remove: ");
            string cname = Console.ReadLine();


            Tch courseToRemove = tch.Find(t => t.sco == cname);
            if (courseToRemove != null)
            {
                tch.Remove(courseToRemove);
                Console.WriteLine("Course removed successfully.");
            }
            else
            {
                Console.WriteLine("Course not found.");
            }
        }
        static void opt3_student(List<Tch> tch)
        {
            Console.WriteLine("Courses: ");
            foreach (Tch c in tch)
            {
                Console.WriteLine($"Course Name: {c.sco}, Course ID: {c.stid}, Credit Hours: {c.sch}");

            }
        }
       
        


    }
}
